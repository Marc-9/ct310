<?php
namespace Model;
use \DB;
class HospitalModel extends \Model {
	public static function read_hospital() {
		return DB::query('SELECT DISTINCT id, name, state From hospital ORDER BY id', DB::SELECT)->execute()->as_array();
    }
     public static function get_hospitals($id) {
		return DB::query("SELECT DISTINCT drg_hospital.drg_id, drg_hospital.hospital_id, financials.average_covered_charges, financials.average_total_payments, financials.average_medicare_payments, hospital.id, hospital.name, hospital.street, hospital.state, hospital.zipcode, hospital.city, drg_hospital.tot_discharge, hospital.referral_region, drg.drg_definition FROM drg_hospital INNER JOIN financials ON drg_hospital.hospital_id = financials.hospital_id INNER JOIN drg ON drg_hospital.drg_id = drg.id INNER JOIN hospital ON drg_hospital.hospital_id = hospital.id WHERE drg_hospital.hospital_id=$id", DB::SELECT)->execute()->as_array();
	}
}
?>
