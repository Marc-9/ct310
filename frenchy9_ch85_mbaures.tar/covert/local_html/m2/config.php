<?php
    if (!defined('DB_HOST')) define('DB_HOST', 'faure.cs.colostate.edu');
    if (!defined('DB_USER')) define('DB_USER', 'frenchy9');
    if (!defined('DB_PASSWORD')) define('DB_PASSWORD', '831954551');
    if (!defined('DB_DATABASE')) define('DB_DATABASE', 'frenchy9');
?>