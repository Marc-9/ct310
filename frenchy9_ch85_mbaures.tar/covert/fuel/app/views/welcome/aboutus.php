<link rel="stylesheet" href="../../assets/css/aboutus.css" type="text/css">

		<div class="chase">
					<a href=""><img src="../../assets/img/chase.jpg" alt="Chase"></a>
					<h3>Chase Howard</h3>
					<p>A sophomore majoring in Computer Science<br>
					See my version of the website <a href='https://cs.colostate.edu:4444/~ch85/ct310/index/welcome/'>HERE</p>
				</div>
				<br>
				
				<div class="frenchy">
					<a href=""><img src="../../assets/img/frenchy.jpeg" alt="Frenchy"></a>
					<h3>Jean-Marc Ruffalo-Burgat</h3>
					<p>I enjoy soccer and programming, sometimes those worlds collide<br>
					See my version of the website <a href='https://cs.colostate.edu:4444/~frenchy9/ct310/index/welcome/'>HERE</a></p>
				</div>
				<br>
				
				<div class="michael">
 					<a href=""><img src="../../assets/img/michael.jpg" alt="Michael"" alt="Michael"></a>
 					<h3>Michael Bauers</h3>
 					<p>A second-year student studying Computer Science and Statistics at CSU<br>
 					See my version of the website <a href='https://cs.colostate.edu:4444/~mbauers/ct310/index/welcome/'>HERE</a></p>
 				</div>

			

