<?php
    if (!defined('DB_HOST')) define('DB_HOST', 'faure.cs.colostate.edu');
    if (!defined('DB_USER')) define('DB_USER', '');
    if (!defined('DB_PASSWORD')) define('DB_PASSWORD', '');
    if (!defined('DB_DATABASE')) define('DB_DATABASE', '');
?>