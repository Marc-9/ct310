<h1 align="center">Who are we</h1>
<img src='../../assets/img/logo.png' style="display:block; margin-left: auto; margin-right: auto;">
<h3 align="center">Covert is as website, made for those who want to get the best prices on their upcoming operations.<br>
As you may know operations in the United States can be very expensive, with our intuitive site, you can see
prices for operations by on Hospital, or view each medical procedure and sort by lowest price.<br>
Keep coming back for more updates, like community interaction through comments.<br>
View the team that made this possible by going to the About Us Page.</h3>